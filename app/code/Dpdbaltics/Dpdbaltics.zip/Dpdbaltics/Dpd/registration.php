<?php

// @codeCoverageIgnoreStart
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Dpdbaltics_Dpd',
    __DIR__
);
// @codeCoverageIgnoreEnd
