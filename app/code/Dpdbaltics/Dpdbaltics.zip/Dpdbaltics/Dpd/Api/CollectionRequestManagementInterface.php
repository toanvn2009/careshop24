<?php

namespace AdeoWeb\Dpd\Api;

interface CollectionRequestManagementInterface
{
    /**
     * Public method
     *
     * @param array $data
     * @return bool
     */
    public function collectionRequest(array $data);
}
