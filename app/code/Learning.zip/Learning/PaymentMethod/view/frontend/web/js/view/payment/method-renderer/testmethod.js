define(
    [
        'jquery',
        'Magento_Checkout/js/view/payment/default',
        'mage/url',
        'Magento_Checkout/js/model/error-processor',
        'Magento_Checkout/js/action/redirect-on-success',
        'Magento_Checkout/js/model/quote',
        'mage/validation'
    ],
    function ($,Component,url, errorProcessor,redirectOnSuccessAction, quote) {
        'use strict';
        
        return Component.extend({
            defaults: {
                template: 'Learning_PaymentMethod/payment/testmethod',
                mpesaNumber:'',
            },
            /** @inheritdoc */
            initObservable: function () {
                this._super()
                    .observe(['mpesaNumber']);

                return this;
            },
            /**
         * @return {Object}
         */
        getData: function () {
            return {
                method: this.item.method,
                // 'mpesanumber': this.mpesaNumber(),
                'additional_data': {
                    'mpesanumber': $('#lipampesanumber').val()
                }
            };
        },
        /**
         * @return {jQuery}
         */
        validate: function () {
            var form = 'form[data-role=mpesanumber_form]';

            return $(form).validation() && $(form).validation('isValid');
        },
       
        });
    }
);