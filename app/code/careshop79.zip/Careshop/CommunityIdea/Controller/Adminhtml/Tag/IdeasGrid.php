<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Tag;

class IdeasGrid extends Ideas
{
}
