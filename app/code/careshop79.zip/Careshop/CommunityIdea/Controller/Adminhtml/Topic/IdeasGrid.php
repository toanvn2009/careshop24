<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Topic;

class IdeasGrid extends Ideas
{
}
