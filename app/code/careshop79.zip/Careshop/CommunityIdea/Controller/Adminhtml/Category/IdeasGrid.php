<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Category;

class IdeasGrid extends Ideas
{
}
