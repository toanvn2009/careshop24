<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Author;

class IdeasGrid extends Ideas
{
}
