<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Idea;

/**
 * Class ProductsGrid
 * @package Careshop\CommunityIdea\Controller\Adminhtml\Idea
 */
class HistoryGrid extends History
{
}
