<?php

namespace Careshop\CommunityIdea\Controller\Adminhtml\Idea;

class ProductsGrid extends Products
{
}
