<?php

namespace Careshop\CommunityIdea\Controller\Idea;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\IdeaFactory;
use Careshop\CommunityIdea\Model\IdeaLikeFactory;
use Careshop\CommunityIdea\Model\ResourceModel\IdeaLike\Collection;

class Review extends Action
{

    /**
     * @var Data
     */
    protected $_helperCommunity;

    /**
     * @var IdeaFactory
     */
    protected $ideaFactory;

    /**
     * @var IdeaLike
     */
    protected $_ideaLike;

    /**
     * @var Collection
     */
    protected $_ideaLikeCollection;

    /**
     * Review constructor.
     *
     * @param Context $context
     * @param IdeaFactory $ideaFactory
     * @param Collection $ideaLikeCollection
     * @param IdeaLikeFactory $ideaLikeFactory
     * @param Data $helperData
     */
    public function __construct(
        Context $context,
        IdeaFactory $ideaFactory,
        Collection $ideaLikeCollection,
        IdeaLikeFactory $ideaLikeFactory,
        Data $helperData
    ) {
        $this->_helperCommunity = $helperData;
        $this->_ideaLikeCollection = $ideaLikeCollection;
        $this->_ideaLike = $ideaLikeFactory;
        $this->ideaFactory = $ideaFactory;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface
     * @throws Exception
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('idea_id');
        $action = $this->getRequest()->getParam('action');
        $mode = $this->getRequest()->getParam('mode');
        $likeId = $this->getRequest()->getParam('likeId');
        $customerId = $this->_helperCommunity->getCurrentUser() ?: 0;
        $idea = $this->ideaFactory->create()->load($id);

        if ($mode === '1') {
            $like = $this->_ideaLikeCollection->addFieldToFilter('entity_id', $customerId)
                ->addFieldToFilter('idea_id', $idea->getId());
            $likeId = $like->getFirstItem()->getId();

            if ($action === '3') {
                return $this->getResponse()->representJson(Data::jsonEncode([
                    'status' => $like->count() > 0 ? 0 : 1,
                    'action' => $like->getFirstItem()->getAction(),
                    'type' => $action
                ]));
            }

            if (!$customerId || !$idea) {
                if ($action === '1') {
                    $this->messageManager->addErrorMessage(__('Can\'t Like Idea.'));
                } else {
                    $this->messageManager->addErrorMessage(__('Can\'t Dislike Idea.'));
                }

                return $this->getResponse()->representJson(Data::jsonEncode([
                    'status' => 0,
                    'type' => $action
                ]));
            }
        }

        try {
            $ideaLike = $this->_ideaLike->create()->load($likeId);

            if ($ideaLike->getId() && $ideaLike->getAction() === $action) {
                $ideaLike->delete();
                $ideaLike->setId(0);
            } else {
                $ideaLike->addData(
                    [
                        'idea_id' => $idea->getId(),
                        'action' => $action,
                        'entity_id' => $customerId
                    ]
                )->save();
            }

            $sumLike = $this->_ideaLike->create()->getCollection()->addFieldToFilter('action', '1')
                ->addFieldToFilter('idea_id', $id);
            $sumDislike = $this->_ideaLike->create()->getCollection()->addFieldToFilter('action', '0')
                ->addFieldToFilter('idea_id', $id);

            return $this->getResponse()->representJson(Data::jsonEncode([
                'status' => 1,
                'type' => $action,
                'sumLike' => $sumLike->count(),
                'sumDislike' => $sumDislike->count(),
                'postLike' => $ideaLike->getId()
            ]));
        } catch (Exception $exception) {
            $this->messageManager->addErrorMessage($exception->getMessage());

            return $this->getResponse()->representJson(Data::jsonEncode([
                'status' => 0,
                'type' => $action
            ]));
        }
    }
}
