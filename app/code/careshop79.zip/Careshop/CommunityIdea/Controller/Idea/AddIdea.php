<?php

namespace Careshop\CommunityIdea\Controller\Idea;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\Result\Redirect;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\View\Result\Page;
use Careshop\CommunityIdea\Model\IdeaFactory;
use Careshop\CommunityIdea\Model\AuthorFactory;
use Careshop\CommunityIdea\Helper\Data as HelperData;
class AddIdea extends Action
{
    /**
     * Idea Factory
     *
     * @var IdeaFactory
     */
    protected $ideaFactory;

    protected $_pageFactory;

    protected $storeManager;
	
	protected $authorFactory;
	/**
     * @var HelperData
     */
    public $helperData;


    public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        IdeaFactory $ideaFactory,
		AuthorFactory $authorFactory,
		HelperData $helperData
        )
	{
		$this->_pageFactory = $pageFactory;
        $this->ideaFactory = $ideaFactory;
        $this->storeManager = $storeManager;
		$this->authorFactory = $authorFactory;
		$this->helperData    = $helperData;
		return parent::__construct($context);
	}

    public function getStoreId()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * @return ResponseInterface|Redirect|ResultInterface|Page
     */
    public function execute()
    {   
		$customer_id = $this->helperData->getCurrentUser();
		$author = $this->authorFactory->create();
		$data = $this->getRequest()->getPost();
		$authorData = array(
			'customer' =>  ($data['author_name'] ? $data['author_name'] : ''),
			'customer_id' => $customer_id,
			'name' => ($data['author_name'] ? $data['author_name'] : ''),
			'status' => 0
		);
		$author->setData($authorData);
		$author->save();
      
        $store_id = $this->getStoreId();
        $ideaData = array(
            'name' => ($data['name']) ? $data['name'] : '',
            'author_id' => $author->getUserId(),
			'author_name' => ($data['author_name'] ? $data['author_name'] : ''),
            'short_description' => ($data['short_description']) ? $data['short_description'] : '',
            'post_content' => ($data['post_content']) ? $data['post_content'] : '',
            'categories_ids' => ($data['categories_ids'] ? explode(',', $data['categories_ids']) : array()),
            'store_ids' => ($store_id) ? array($store_id) : '0',
			'enabled' => 1
        );
        
        //echo "<pre>"; print_r($ideaData); die; 
        /** @var \Careshop\CommunityIdea\Model\Idea $idea */
        $idea = $this->ideaFactory->create();
        $idea->setData($ideaData);
        $idea->save();
        $this->messageManager->addSuccessMessage(__('The idea has been added.'));

        $resultRedirect = $this->resultRedirectFactory->create();

        $resultRedirect->setPath('community/*/index');

        return $resultRedirect;
    }
}
