<?php

namespace Careshop\CommunityIdea\Controller\Idea;

use Exception;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Stdlib\DateTime\DateTime;
use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\IdeaFactory;

class DeleteIdea extends Action
{
    /**
     * @var IdeaFactory
     */
    protected $ideaFactory;

    /**
     * @var DateTime
     */
    protected $date;

    /**
     * @var Data
     */
    protected $_helperCommunity;

    /**
     * DeleteIdea constructor.
     *
     * @param Context $context
     * @param IdeaFactory $ideaFactory
     * @param Data $helperData
     */
    public function __construct(
        Context $context,
        IdeaFactory $ideaFactory,
        Data $helperData
    ) {
        $this->_helperCommunity = $helperData;
        $this->ideaFactory = $ideaFactory;

        parent::__construct($context);
    }

    /**
     * @return ResponseInterface|ResultInterface|null
     */
    public function execute()
    {
        $ideaId = $this->getRequest()->getParam('idea_id');
        $this->_helperCommunity->setCustomerContextId();
        $author = $this->_helperCommunity->getCurrentAuthor();
        $idea = $this->ideaFactory->create();

        if (!$author || !$ideaId) {
            return null;
        }

        try {
            $idea->load($ideaId)->delete();
            $this->messageManager->addSuccessMessage(__('The idea has been deleted.'));

            return $this->getResponse()->representJson(Data::jsonEncode([
                'status' => 1,
                'idea_id' => $ideaId
            ]));
        } catch (Exception $exception) {
            $this->messageManager->addErrorMessage($exception->getMessage());

            return $this->getResponse()->representJson(Data::jsonEncode([
                'status' => 0
            ]));
        }
    }
}
