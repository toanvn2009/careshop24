<?php

namespace Careshop\CommunityIdea\Block\Sidebar;

use Careshop\CommunityIdea\Block\Frontend;
use Careshop\CommunityIdea\Model\ResourceModel\Idea\Collection;

class MostView extends Frontend
{
    /**
     * @return Collection
     */
    public function getMostViewIdeas()
    {
        $collection = $this->helperData->getIdeaList();
        $collection->getSelect()
            ->joinLeft(
                ['traffic' => $collection->getTable('community_idea_traffic')],
                'main_table.idea_id=traffic.idea_id',
                'numbers_view'
            )
            ->order('numbers_view DESC')
            ->limit((int)$this->helperData->getCommunityConfig('sidebar/number_mostview_ideas') ?: 4);

        return $collection;
    }

    /**
     * @return Collection
     */
    public function getRecentIdea()
    {
        $collection = $this->helperData->getIdeaList();
        $collection->getSelect()
            ->limit((int)$this->helperData->getCommunityConfig('sidebar/number_recent_ideas') ?: 4);

        return $collection;
    }
}
