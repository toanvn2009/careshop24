<?php

namespace Careshop\CommunityIdea\Block\Widget;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Widget\Block\BlockInterface;
use Careshop\CommunityIdea\Block\Frontend;
use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\ResourceModel\Idea\Collection;

/**
 * Class Ideas
 * @package Careshop\CommunityIdea\Block\Widget
 */
class Ideas extends Frontend implements BlockInterface
{
    /**
     * @var string
     */
    protected $_template = "widget/ideas.phtml";

    /**
     * @return Collection
     * @throws NoSuchEntityException
     */
    public function getCollection()
    {
        if ($this->hasData('show_type') && $this->getData('show_type') === 'category') {
            $collection = $this->helperData->getObjectByParam($this->getData('category_id'), null, Data::TYPE_CATEGORY)
                ->getSelectedIdeasCollection();
            $this->helperData->addStoreFilter($collection);
        } else {
            $collection = $this->helperData->getIdeaList();
        }

        $collection->setPageSize($this->getData('idea_count'));

        return $collection;
    }

    /**
     * @return Data
     */
    public function getHelperData()
    {
        return $this->helperData;
    }

    /**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->getData('title');
    }

    /**
     * @param $code
     *
     * @return string
     */
    public function getCommunityUrl($code)
    {
        return $this->helperData->getCommunityUrl($code);
    }
}
