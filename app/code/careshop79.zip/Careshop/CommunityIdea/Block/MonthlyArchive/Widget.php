<?php

namespace Careshop\CommunityIdea\Block\MonthlyArchive;

use Exception;
use Magento\Framework\Exception\NoSuchEntityException;
use Careshop\CommunityIdea\Block\Frontend;
use Careshop\CommunityIdea\Helper\Data as DataHelper;

class Widget extends Frontend
{
    /**
     * @var array
     */
    protected $_ideaDate;

    /**
     * @return mixed
     */
    public function isEnable()
    {
        return $this->helperData->getCommunityConfig('monthly_archive/enable_monthly');
    }

    /**
     * @return array
     * @throws NoSuchEntityException
     */
    public function getDateArrayCount()
    {
        return array_values(array_count_values($this->getDateArray()));
    }

    /**
     * @return array
     * @throws NoSuchEntityException
     */
    public function getDateArrayUnique()
    {
        return array_values(array_unique($this->getDateArray()));
    }

    /**
     * @return array
     * @throws NoSuchEntityException
     */
    public function getDateArray()
    {
        $dateArray = [];
        foreach ($this->getIdeaDate() as $ideaDate) {
            $dateArray[] = date("F Y", $this->dateTime->timestamp($ideaDate));
        }

        return $dateArray;
    }

    /**
     * @return array
     * @throws NoSuchEntityException
     */
    protected function getIdeaDate()
    {
        if (!$this->_ideaDate) {
            $ideas = $this->helperData->getIdeaList();
            $ideaDates = [];
            if ($ideas->getSize()) {
                foreach ($ideas as $idea) {
                    $ideaDates[] = $idea->getPublishDate();
                }
            }
            $this->_ideaDate = $ideaDates;
        }

        return $this->_ideaDate;
    }

    /**
     * @return int|void
     * @throws NoSuchEntityException
     */
    public function getDateCount()
    {
        $limit = $this->helperData->getCommunityConfig('monthly_archive/number_records') ?: 5;
        $dateArrayCount = $this->getDateArrayCount();
        $count = count($dateArrayCount);

        return ($count < $limit) ? $count : $limit;
    }

    /**
     * @param $month
     *
     * @return string
     */
    public function getMonthlyUrl($month)
    {
        return $this->helperData->getCommunityUrl($month, DataHelper::TYPE_MONTHLY);
    }

    /**
     * @return array
     * @throws Exception
     */
    public function getDateLabel()
    {
        $ideaDates = $this->getIdeaDate();
        $ideaDatesLabel = [];
        if (count($ideaDates)) {
            foreach ($ideaDates as $date) {
                $ideaDatesLabel[] = $this->helperData->getDateFormat($date, true);
            }
        }

        return array_values(array_unique($ideaDatesLabel));
    }
}
