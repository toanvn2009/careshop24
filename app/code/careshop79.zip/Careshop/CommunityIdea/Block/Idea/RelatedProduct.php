<?php

namespace Careshop\CommunityIdea\Block\Idea;

use Exception;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Catalog\Block\Product\ListProduct;
use Magento\Catalog\Helper\Output;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Framework\Url\Helper\Data;
use Careshop\CommunityIdea\Helper\Data as HelperData;

class RelatedProduct extends ListProduct
{
    /**
     * Default related product page title
     */
    const TITLE = 'Related Products';

    /**
     * Default limit related products
     */
    const LIMIT = '12';

    /**
     * @var CollectionFactory
     */
    protected $_productCollectionFactory;

    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * @var Output
     */
    protected $outputHelper;

    /**
     * @var Configurable
     */
    protected $catalogProductTypeConfigurable;

    /**
     * @var ProductRepository
     */
    protected $productRepository;

    /**
     * RelatedProduct constructor.
     *
     * @param Context $context
     * @param PostHelper $ideaDataHelper
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param CollectionFactory $productCollectionFactory
     * @param Configurable $catalogProductTypeConfigurable
     * @param ProductRepository $productRepository
     * @param HelperData $helperData
     * @param Output $output
     * @param Data $urlHelper
     * @param array $data
     */
    public function __construct(
        Context $context,
        PostHelper $ideaDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        CollectionFactory $productCollectionFactory,
        Configurable $catalogProductTypeConfigurable,
        ProductRepository $productRepository,
        HelperData $helperData,
        Output $output,
        Data $urlHelper,
        array $data = []
    ) {
        $this->_productCollectionFactory      = $productCollectionFactory;
        $this->helper                         = $helperData;
        $this->outputHelper                   = $output;
        $this->catalogProductTypeConfigurable = $catalogProductTypeConfigurable;
        $this->productRepository              = $productRepository;

        parent::__construct($context, $ideaDataHelper, $layerResolver, $categoryRepository, $urlHelper, $data);
    }

    /**
     * @return Output
     */
    public function getHelper()
    {
        return $this->outputHelper;
    }

    /**
     * @return mixed
     */
    public function relatedMode()
    {
        return $this->helper->getModuleConfig('product_idea/idea_detail/related_mode');
    }

    /**
     * @return mixed
     */
    public function hasProduct()
    {
        $collection = $this->_getProductCollection();

        return $collection->getSize();
    }

    /**
     * Get ProductCollection in same brand (filter by Attribute Option_Id)
     *
     * @return mixed
     */
    public function _getProductCollection()
    {
        if ($this->_productCollection === null) {
            $ideaId     = $this->getRequest()->getParam('id');
            $collection = $this->_productCollectionFactory->create()
                ->addAttributeToSelect('*')
                ->addStoreFilter();

            $collection->getSelect()
                ->join(
                    ['product_idea' => $collection->getTable('community_idea_product')],
                    'e.entity_id = product_idea.entity_id'
                )
                ->where('product_idea.idea_id = ' . $ideaId)
                ->order('product_idea.position ASC')
                ->limit((int) $this->helper->getCommunityConfig('product_idea/idea_detail/product_limit') ?: self::LIMIT);

            $this->_productCollection = $collection;
        }

        return $this->_productCollection;
    }

    /**
     * @inheritdoc
     */
    public function getMode()
    {
        return 'grid';
    }

    /**
     * @inheritdoc
     */
    public function getToolbarHtml()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    public function getAdditionalHtml()
    {
        return null;
    }

    /**
     * @inheritdoc
     */
    protected function _beforeToHtml()
    {
        return $this;
    }

    /**
     * @param Product $product
     *
     * @return mixed
     */
    public function getParentProductUrl($product)
    {
        $parentByChild = $this->catalogProductTypeConfigurable->getParentIdsByChild($product->getId());
        if (isset($parentByChild[0])) {
            try {
                $parentProduct = $this->productRepository->getById($parentByChild[0]);

                return $parentProduct->getProductUrl();
            } catch (Exception $e) {
                return $product->getProductUrl();
            }
        }

        return $product->getProductUrl();
    }
}
