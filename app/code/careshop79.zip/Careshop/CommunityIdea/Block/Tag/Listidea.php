<?php

namespace Careshop\CommunityIdea\Block\Tag;

use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\ResourceModel\Idea\Collection;
use Careshop\CommunityIdea\Model\TagFactory;

class Listidea extends \Careshop\CommunityIdea\Block\Listidea
{
    /**
     * @var TagFactory
     */
    protected $_tag;

    /**
     * Override this function to apply collection for each type
     *
     * @return Collection
     */
    protected function getCollection()
    {
        if ($tag = $this->getCommunityObject()) {
            return $this->helperData->getIdeaCollection(Data::TYPE_TAG, $tag->getId());
        }

        return null;
    }

    /**
     * @return mixed
     */
    protected function getCommunityObject()
    {
        if (!$this->_tag) {
            $id = $this->getRequest()->getParam('id');

            if ($id) {
                $tag = $this->helperData->getObjectByParam($id, null, Data::TYPE_TAG);
                if ($tag && $tag->getId()) {
                    $this->_tag = $tag;
                }
            }
        }

        return $this->_tag;
    }

    /**
     * @inheritdoc
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();

        if ($breadcrumbs = $this->getLayout()->getBlock('breadcrumbs')) {
            $tag = $this->getCommunityObject();
            if ($tag) {
                $breadcrumbs->addCrumb($tag->getUrlKey(), [
                    'label' => __('Tag'),
                    'title' => __('Tag')
                ]);
            }
        }
    }

    /**
     * @param bool $meta
     *
     * @return array
     */
    public function getCommunityTitle($meta = false)
    {
        $communityTitle = parent::getCommunityTitle($meta);
        $tag = $this->getCommunityObject();
        if (!$tag) {
            return $communityTitle;
        }

        if ($meta) {
            if ($tag->getMetaTitle()) {
                array_push($communityTitle, $tag->getMetaTitle());
            } else {
                array_push($communityTitle, ucfirst($tag->getName()));
            }

            return $communityTitle;
        }

        return ucfirst($tag->getName());
    }
}
