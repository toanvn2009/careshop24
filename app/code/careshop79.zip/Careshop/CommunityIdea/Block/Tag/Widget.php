<?php

namespace Careshop\CommunityIdea\Block\Tag;

use Exception;
use Magento\Framework\Exception\NoSuchEntityException;
use Careshop\CommunityIdea\Block\Frontend;
use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\ResourceModel\Idea\Collection;
use Careshop\CommunityIdea\Model\ResourceModel\Author\Collection as AuthorCollection;
use Careshop\CommunityIdea\Model\ResourceModel\Category\Collection as CategoryCollection;
use Careshop\CommunityIdea\Model\ResourceModel\Tag\Collection as TagCollection;
use Careshop\CommunityIdea\Model\ResourceModel\Topic\Collection as TopicCollection;
use Careshop\CommunityIdea\Model\Tag;

class Widget extends Frontend
{
    /**
     * @var TagCollection
     */
    protected $_tagList;

    /**
     * @return AuthorCollection|CategoryCollection|Collection|TagCollection|TopicCollection|null
     */
    public function getTagList()
    {
        try {
            if (!$this->_tagList) {
                $this->_tagList = $this->helperData->getObjectList(Data::TYPE_TAG);
            }

            return $this->_tagList;
        } catch (Exception $e) {
            return null;
        }
    }

    /**
     * @param Tag $tag
     *
     * @return string
     */
    public function getTagUrl($tag)
    {
        return $this->helperData->getCommunityUrl($tag, Data::TYPE_TAG);
    }

    /**
     * Get tags size based on num of post
     *
     * @param $tag
     *
     * @return false|float|int
     * @throws NoSuchEntityException
     */
    public function getTagSize($tag)
    {
        /** @var Collection $ideaList */
        $ideaList = $this->helperData->getIdeaList();
        if ($ideaList && ($max = $ideaList->getSize()) > 1) {
            $maxSize = 22;
            $tagIdea = $this->helperData->getIdeaCollection(Data::TYPE_TAG, $tag->getId());
            if ($tagIdea && ($countTagIdea = $tagIdea->getSize()) > 1) {
                $size = $maxSize * $countTagIdea / $max;

                return round($size) + 8;
            }
        }

        return 8;
    }
}
