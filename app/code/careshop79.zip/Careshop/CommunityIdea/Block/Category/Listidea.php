<?php

namespace Careshop\CommunityIdea\Block\Category;

use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;
use Careshop\CommunityIdea\Helper\Data;
use Careshop\CommunityIdea\Model\ResourceModel\Idea\Collection;

class Listidea extends \Careshop\CommunityIdea\Block\Listidea
{
    /**
     * @var string
     */
    protected $_category;

    /**
     * Override this function to apply collection for each type
     *
     * @return Collection|null
     * @throws NoSuchEntityException
     */
    protected function getCollection()
    {
        if ($category = $this->getCommunityObject()) {
            return $this->helperData->getIdeaCollection(Data::TYPE_CATEGORY, $category->getId());
        }

        return null;
    }

    /**
     * @return mixed
     */
    protected function getCommunityObject()
    {
        if (!$this->_category) {
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $category = $this->helperData->getObjectByParam($id, null, Data::TYPE_CATEGORY);
                if ($category && $category->getId()) {
                    $this->_category = $category;
                }
            }
        }

        return $this->_category;
    }

    /**
     * @inheritdoc
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();

        if ($breadcrumbs = $this->getLayout()->getBlock('breadcrumbs')) {
            $category = $this->getCommunityObject();
            $categoryName = preg_replace('/[^A-Za-z0-9\-]/', ' ', $category->getName());
            if ($category) {
                $breadcrumbs->addCrumb($category->getUrlKey(), [
                    'label' => __($categoryName),
                    'title' => __($categoryName)
                ]);
            }
        }
    }

    /**
     * @param bool $meta
     *
     * @return array|Phrase|string
     */
    public function getCommunityTitle($meta = false)
    {
        $communityTitle = parent::getCommunityTitle($meta);
        $category  = $this->getCommunityObject();
        if (!$category) {
            return $communityTitle;
        }

        if ($meta) {
            if ($category->getMetaTitle()) {
                array_push($communityTitle, $category->getMetaTitle());
            } else {
                array_push($communityTitle, ucfirst($category->getName()));
            }

            return $communityTitle;
        }

        return ucfirst($category->getName());
    }
}
