<?php

namespace Careshop\CommunityIdea\Block\Author;

use Careshop\CommunityIdea\Block\Frontend;
use Careshop\CommunityIdea\Helper\Data;

class Widget extends Frontend
{
    /**
     * @return mixed
     */
    public function getCurrentAuthor()
    {
        $authorId = $this->getRequest()->getParam('id');
        if ($authorId) {
            $author = $this->helperData->getObjectByParam($authorId, null, Data::TYPE_AUTHOR);
            if ($author && $author->getId()) {
                return $author;
            }
        }

        return null;
    }
}
