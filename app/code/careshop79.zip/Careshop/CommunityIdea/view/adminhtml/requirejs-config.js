
var config = {
    map: {
        '*': {
            categoryForm: 'Careshop_CommunityIdea/category/form'
        }
    }
};
