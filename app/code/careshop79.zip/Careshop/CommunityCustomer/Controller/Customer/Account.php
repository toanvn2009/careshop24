<?php

namespace Careshop\CommunityCustomer\Controller\Customer;

/**
 * Cummunity Custommer  Page 
 */
class Account extends \Magento\Framework\App\Action\Action
{
    /**
     * View Cummunity action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {   
        $this->_view->loadLayout();
        $this->_view->renderLayout();
    }

}
