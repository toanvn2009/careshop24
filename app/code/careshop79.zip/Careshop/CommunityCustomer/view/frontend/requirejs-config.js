var config = {
    "map": {
        '*': {
			'community_customer': 'Careshop_CommunityCustomer/js/community'
        },
    }
};