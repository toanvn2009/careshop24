<?php

namespace AdeoWeb\Dpd\Api;

interface CloseManifestManagementInterface
{
    /**
     * Public method
     *
     * @return array
     * @throws \Exception
     */
    public function closeManifest();
}
