<?php

namespace AdeoWeb\Dpd\Model\Config\Source;

class ApiUrl extends Generic
{
    const TYPE = 'api_url';

    /**
     * @var string
     */
    protected $code = self::TYPE;
}
