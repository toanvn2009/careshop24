<?php

namespace AdeoWeb\Dpd\Model\Config\Source;

class Method extends Generic
{
    const TYPE = 'method';

    /**
     * @var string
     */
    protected $code = self::TYPE;
}
