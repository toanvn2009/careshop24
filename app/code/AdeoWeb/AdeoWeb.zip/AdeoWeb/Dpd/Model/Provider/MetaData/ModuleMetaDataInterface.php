<?php

namespace AdeoWeb\Dpd\Model\Provider\MetaData;

interface ModuleMetaDataInterface
{
    /**
     * @return string
     */
    public function getVersion(): string;
}
